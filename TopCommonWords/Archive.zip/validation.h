#ifndef INC_TOPCOMMONWORDS_VALIDATION_H
#define INC_TOPCOMMONWORDS_VALIDATION_H

    #include <iostream>
    #include <string>
    #include <cctype>
    #include <algorithm>
    void remove_symbols(std::string& input);
    void set_lowercase(std::string& input);

#endif //INC_TOPCOMMONWORDS_VALIDATION_H
